<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Digiperpus | Sistem Perpustakaan Digital</title>
  <link rel="stylesheet" href="assets/css/tailwind.css">

</head>
<body class="bg-teal-50">

</body>
</html>
