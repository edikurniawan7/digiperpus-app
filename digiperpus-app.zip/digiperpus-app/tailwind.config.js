module.exports = {
  content: [
    "./*.php",
    "./auth/*.php",
    "./admin/*.php"
  ],
  theme: {
    extend: {
      colors: {
        'blue-primary': '#2563eb',    // biru
        'teal-primary': '#14b6'    // teal
      },
    },
  },
  plugins: [],
}
